import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class TextHow extends Text{
    private int timing=0;
    
    public void act(){
        if(timing>0){
            timing-=5;
            getImage().setTransparency(255-timing);
        }
        else if(timing<0){
            timing+=5;
            getImage().setTransparency(0-timing);
            if(timing==0){
                getWorld().removeObject(this);
            }
        }
    }
    
    public void open(){
        this.timing=255;
    }
    
    public void close(){
        this.timing=-255;
    }
}
