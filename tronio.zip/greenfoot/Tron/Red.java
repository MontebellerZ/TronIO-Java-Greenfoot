import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Red extends Moto{
    private int limiteCount = 0;
    private int limite = 3;
    
    public Red(){
        setCor();
        this.limiteCount = this.limite;
        turn(180);
    }
    
    public void act(){
        if(!getFim()){
            move(getVelocidade());
        }
        virar();
        rastro();
        if(!getFim()){
            tocar();
        }
        boost();
    }
    
    public void virar(){
        if(Greenfoot.isKeyDown("left")){
            turn(-2);
        }
        if(Greenfoot.isKeyDown("right")){
            turn(2);
        }
        if(Greenfoot.isKeyDown("enter")){
            flash();
        }
    }
    
    public void rastro(){
        if(getBlocked()==0){
            this.limiteCount--;
            if(this.limiteCount==0){
                this.limiteCount = this.limite;
                
                double radiano = Math.toRadians(this.getRotation());
                int pX = (int)(48*(Math.cos(radiano)));
                int pY = (int)(48*(Math.sin(radiano)));
                
                pX = this.getX() - pX;
                pY = this.getY() - pY;
                
                this.getWorld().addObject(new RastroRed(), pX, pY);
            }
        }
        else if(getBlocked()==120){
            setBlocked();
            getWorld().removeObjects(getWorld().getObjects(RastroRed.class));
        }
        else{
            setBlocked();
        }
    }
}
