import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class BarBlue extends Bar{
    private int level=0;
    private GreenfootImage bar = new GreenfootImage("flash4.png");
    
    public BarBlue(){
        bar.scale(300, 45);
        setImage(bar);
    }
    
    public void addFlash(){
        if(this.level==3){
            this.level=0;
        }
        else{
            this.level++;
        }
        
        switch(this.level){
            case 0:
                bar = new GreenfootImage("flash4.png");
                break;
            case 1:
                bar = new GreenfootImage("flash5.png");
                break;
            case 2:
                bar = new GreenfootImage("flash6.png");
                break;
            case 3:
                bar = new GreenfootImage("flash7.png");
                break;
        }
        bar.scale(300, 45);
        setImage(bar);
    }
}
