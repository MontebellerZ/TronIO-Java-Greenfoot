import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;

public class Wall extends Actor{
    public Wall(int lado){
        GreenfootImage image = getImage();
        switch(lado){
            case 1:
                image.scale(1280,1);
                break;
            case 2:
                image.scale(1,720);
                break;
        }
        setImage(image);
    }    
}
