import greenfoot.*;

public class Game extends World{
    //private GreenfootSound somMoto = new GreenfootSound("moto.mp3");
    private GreenfootSound somMoto = new GreenfootSound("motoprofetas2.mp3");
    private GreenfootSound somGG = new GreenfootSound("gg.mp3");
    private GreenfootSound somEmpate = new GreenfootSound("empate.mp3");
    
    private static int vitBlue=0;
    private static int vitRed=0;
    
    private boolean fim=false;
    
    private Wall wallTop = new Wall(1);
    private Wall wallTop2 = new Wall(1);
    private Wall wallRight = new Wall(2);
    private Wall wallBottom = new Wall(1);
    private Wall wallBottom2 = new Wall(1);
    private Wall wallLeft = new Wall(2);
    
    private Blue motoblue = new Blue();
    private Red motored = new Red();
    
    private BarBlue barblue = new BarBlue();
    private BarRed barred = new BarRed();
    
    private Empate empate = new Empate();
    private VitBlue vitoriaBlue = new VitBlue();
    private VitRed vitoriaRed = new VitRed();
    
    private Restart restart = new Restart();
    private MenuBtn menubtn = new MenuBtn();
    
    private Drop drop1 = new Drop();
    private Drop drop2 = new Drop();
    private Drop drop3 = new Drop();
    private Drop drop4 = new Drop();
    
    public Game(){
        super(1280, 720, 1);
        showText("Vitórias", 640, 85);
        showText("Azul: "+vitBlue, 320, 85);
        showText("Vermelho: "+vitRed, 960, 85);
        
        addObject(wallTop, 640, 47);
        addObject(wallTop2, 640, 20);
        addObject(wallRight, 1269, 360);
        addObject(wallBottom, 640, 672);
        addObject(wallBottom2, 640, 700);
        addObject(wallLeft, 10, 360);
        
        addObject(motoblue, 200, 360);
        addObject(motored, 1080, 360);
        
        addObject(barblue, 160, 695);
        addObject(barred, 1120, 695);
        
        somMoto.playLoop();
        somMoto.setVolume(25);
        
        setPaintOrder(Button.class,Text.class);
    }
    
    public void act(){
        teclado();
        if(fim){
            motored.turn(6);
            motoblue.turn(6);
        }
        droppar();
    }
    
    public void teclado(){
        if(Greenfoot.isKeyDown("escape")){
            somMoto.stop();
            Greenfoot.setWorld(new Menu());
        }
        if(Greenfoot.isKeyDown("r")){
            somMoto.stop();
            somGG.stop();
            somEmpate.stop();
            Greenfoot.setWorld(new Game());
        }
    }
    
    public void droppar(){
        Moto motoca = new Moto();
        if(!motoca.getFim()){
            Drop drop5 = new Drop();
            
            int chance = Greenfoot.getRandomNumber(6000);
            if(chance<20){
                int xDrop = Greenfoot.getRandomNumber(100);
                int nDrop = Greenfoot.getRandomNumber(4);
                int pX = Greenfoot.getRandomNumber(1160)+60;
                int pY = Greenfoot.getRandomNumber(526)+97;
                if(xDrop<60){
                    drop5 = new Raio();
                }
                else if(xDrop<70){
                    drop5 = new Blocker();
                }
                else if(xDrop<85){
                    drop5 = new Gas();
                }
                else{
                    drop5 = new Spike();
                }
                switch(nDrop){
                    case 0:
                        removeObject(drop1);
                        drop1 = drop5;
                        addObject(drop1,pX,pY);
                        break;
                    case 1:
                        removeObject(drop2);
                        drop2 = drop5;
                        addObject(drop2,pX,pY);
                        break;
                    case 2:
                        removeObject(drop3);
                        drop3 = drop5;
                        addObject(drop3,pX,pY);
                        break;
                    case 3:
                        removeObject(drop4);
                        drop4 = drop5;
                        addObject(drop4,pX,pY);
                        break;
                }
            }
        }
        else{
            removeObjects(getObjects(Drop.class));
        }
    }
    
    public void flashing(Moto motoca){
        if(motoblue==motoca){
            barblue.addFlash();
        }
        else if(motored==motoca){
            barred.addFlash();
        }
    }
    
    public void flashGif(int x, int y){
        DashSmoke smoke = new DashSmoke();
        addObject(smoke, x, y);
    }
    
    public void boom(int x, int y){
        fim=true;
        
        vitBlue+=motored.getMorte();
        vitRed+=motoblue.getMorte();
        
        if(motored.getMorte()>0){
            addObject(vitoriaBlue, 640, 300);
        }
        else if(motoblue.getMorte()>0){
            addObject(vitoriaRed, 640, 300);
        }
        else{
            addObject(empate, 640, 300);
        }
        addObject(restart, 540, 400);
        addObject(menubtn, 740, 400);
        
        somMoto.stop();
        if(motored.getMorte()==1 || motoblue.getMorte()==1){
            somGG.setVolume(40);
            somGG.play();
        }
        else{
            somEmpate.setVolume(40);
            somEmpate.play();
        }
        Greenfoot.playSound("boom1.mp3");
        Boom boom = new Boom();
        addObject(boom, x, y-40);
    }
}
