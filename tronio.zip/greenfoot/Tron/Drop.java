import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Drop extends Actor{
    public Drop(){
        GreenfootImage image = getImage();
        image.scale(40, 40);
        setImage(image);
    }
}
