import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class RastroRed extends Rastro{
    private GreenfootImage rastro = getImage();
    
    public RastroRed(){
        rastro.scale(15,15);
        setImage(rastro);
    }
    
    public void act(){
        dead();
    }
}
