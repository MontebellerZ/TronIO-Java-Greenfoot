import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class BarRed extends Bar{
    private int level=0;
    private GreenfootImage bar = new GreenfootImage("flash0.png");
    
    public BarRed(){
        bar.scale(300, 45);
        setImage(bar);
    }
    
    public void addFlash(){
        if(this.level==3){
            this.level=0;
        }
        else{
            this.level++;
        }
        
        switch(this.level){
            case 0:
                bar = new GreenfootImage("flash0.png");
                break;
            case 1:
                bar = new GreenfootImage("flash1.png");
                break;
            case 2:
                bar = new GreenfootImage("flash2.png");
                break;
            case 3:
                bar = new GreenfootImage("flash3.png");
                break;
        }
        bar.scale(300, 45);
        setImage(bar);
    }
}
