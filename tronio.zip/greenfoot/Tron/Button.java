import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Button extends Actor{
    public void som(){
        GreenfootSound botao = new GreenfootSound("botao.mp3");
        botao.setVolume(40);
        botao.play();
    }
}